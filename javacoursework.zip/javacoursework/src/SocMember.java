public class SocMember {

    private String name; //private variable for name
    private int number; //private variable for society member's number

    public static int student_counter = 0; //initialised at 0, keeps count of members in a society

    SocMember(String name, int number) {
        this.name = name; //assigns member's name to the variable
        this.number = number; //assigns member's number to the variable
        student_counter++; //increments by 1 for each instantiation of a societyMember created

    }

    public void setName(String newName) {
        name = newName; //new name is set for member
    }

    public void setNumber(int newNum) {
        number = newNum; //new number is set for member
    }

    public String getName() {
        return name; //new name is set for member
    }

    public int getNumber() {
        return number; //new number is set for member
    }
}