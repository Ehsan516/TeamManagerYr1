public class SocTeam {

    private SocMember president; //is assigned to a specific member in the team, restricted to SocTeam
    private SocMember secretary; //is assigned to a specific member in the team, restricted to SocTeam
    private SocMember treasurer; //is assigned to a specific member in the team, restricted to SocTeam

    private String teamName; //teamName to help identify
    SocTeam(SocMember pres, SocMember secr, SocMember treas, String teamName) {

        this.president = pres; //First parameter from SocTeam is assigned to president
        this.secretary = secr; //Second parameter from SocTeam is assigned to secretary
        this.treasurer = treas; //Third parameter from SocTeam is assigned to treasurer
        this.teamName = teamName; //Assigns last parameter to team name
    }

    //Constructor for society's that do not use members from the members array
    SocTeam(String pres,int presNum,String secr,int secrNum, String treas,int treasNum,String teamName){
        this.president = new SocMember(pres,presNum); //creates a president SocMember using the 2 parameters
        this.secretary = new SocMember(secr, secrNum); //creates a secretary SocMember using the 2 parameters
        this.treasurer = new SocMember(treas,treasNum); //creates a treasurer SocMember using the 2 parameters
        this.teamName = teamName; //Assigns last parameter to team name
    }

    public String getPresidentName() { //getter method for the president's name
        return president.getName(); //the getName function from SocMember is called upon and returns the string
    }

    public String getSecretaryName() { //getter method for the secretary's name
        return secretary.getName(); //the getName function from SocMember is called upon and returns the string
    }

    public String getTreasureName() { //getter method for the treasurer's name
        return treasurer.getName(); //the getName function from SocMember is called upon and returns the string
    }

    public String getTeamName() { //getter method for the treasurer's name
        return teamName; //the getName function from SocMember is called upon and returns the string
    }
}