import java.util.Random;

public class Main {
    public static void main(String[] args) {


        String[] allStudentNames = {"Ehsan", "Robleh", "Saadee", "Hamid", "Azim", "Zayn"}; //initialised string array holding 6 student names
        int[] allStudentNumbers = {1, 2, 3, 4, 5, 6}; //initialised string array holding 6 student numbers
        SocMember[] members; //initialised the members array of type SocMember

        int randomizer = new Random().nextInt(3); //random number between 0 and 2

        int numMembers = randomizer + 4; //minimum member is 4 and max is 6 when adding 4
        System.out.println(numMembers); //Prints out the amount of members that will be stored to the member's array

        members = new SocMember[numMembers]; //initialises members array with a length

        for (int i = 0; i < numMembers; i++) {
            int chosen = new Random().nextInt(allStudentNames.length); //a random number within the length of the array is generated

            while (allStudentNames[chosen] == null) {
                chosen = new Random().nextInt(allStudentNames.length); //if the index happens to land on a null value,it generates a random number to index
            }

            members[i] = new SocMember(allStudentNames[chosen], allStudentNumbers[chosen]);
            //member of index 'i' is created with the coresponding name and student number
            System.out.println(members[i].getName() + " , " + members[i].getNumber());

            allStudentNames[chosen] = null; //name is made null to prevent repeat for the 'while' loop above
        }

//        System.out.println(members.length);
//        System.out.println(SocMember.student_counter);

        //Women Soc

        SocTeam women_soc = new SocTeam(members[0], members[1], members[2], "WomenSoc"); //initialised a women's society with the first 3 members taking on roles
        System.out.println(women_soc.getTeamName() + "'s president is " + women_soc.getPresidentName());
        System.out.println(women_soc.getTeamName() + "'s secretary is " + women_soc.getSecretaryName());
        System.out.println(women_soc.getTeamName() + "'s treasurer is " + women_soc.getTreasureName());


        //Bame Soc
        SocTeam bame_soc = new SocTeam(members[members.length - 1], members[members.length - 2], members[members.length - 3], "BameSoc"); //initialised a bame's society with the last 3 members taking on roles
        System.out.println(bame_soc.getTeamName() + "'s president is " + bame_soc.getPresidentName());
        System.out.println(bame_soc.getTeamName() + "'s secretary is " + bame_soc.getSecretaryName());
        System.out.println(bame_soc.getTeamName() + "'s treasurer is " + bame_soc.getTreasureName());

        if (SocMember.student_counter == members.length) {
            System.out.println("SUCCESS");
        }

        //Testing different constructor
//        SocTeam sci_soc = new SocTeam(new SocMember("bob", 56), new SocMember("john", 32), new SocMember("tank", 44), "sciSoc");
//        System.out.println(sci_soc.getPresidentName());


    }
}